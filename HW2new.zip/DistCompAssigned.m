%Example: disturbance compensation
%this version with compensation implemented
clear;clc;close all

%find where to add these lines to the no-compensation code

Cdelta= %code for this

f=2*Hy'*(Py*x-r+delta*Cdelta);


delta=(ypred_end-ynext(end));


